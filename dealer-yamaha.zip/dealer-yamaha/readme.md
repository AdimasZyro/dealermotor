# Penjualan Hasil Pertanian
Website penjualan hasil pertanian dengan menggunakan framework CodeIgniter ini memiliki tampilan yang sederhana dan fitur yang mampu berfungsi dengan baik.

To access admin page, add url /admin. Example http://localhost/ksucatalog/auth

## Tampilan Aplikasi
![ss](asset/ss1.png)
![ss](asset/ss2.png)
![ss](asset/ss3.png)

## Admin Account
| Level |  Username | Password |
|:-----:|:---------:|---------:|
| Admin |  admin    | admin    |
| User  |  customer | customer |

## Sistem Requirement
- CodeIgniter
- Database MySQL
- XAMPP / PHP 5.6
